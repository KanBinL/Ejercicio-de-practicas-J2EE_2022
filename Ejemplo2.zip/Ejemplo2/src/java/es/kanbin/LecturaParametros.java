/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.kanbin;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DAW204
 */
public class LecturaParametros extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
            
            String nombreParametro = null;
            String[] valoresParametro = null;
            Iterator it;
        
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LecturaParametros</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LecturaParametros at " + request.getContextPath() + "</h1>");
            
            out.println("apellidos: ");
            out.println(request.getParameter("apellidos"));
            out.println("<br>");
            out.println("nombre: ");
            out.println(request.getParameter("nombre"));
            out.println("<br>");
            
            String[] aficiones = null;
            aficiones = request.getParameterValues("aficines");
            out.println("aficiones: ");
            for (String aficion:aficiones){
                out.println(aficion + " ");
            }
            out.println("<br>");
            
            out.println("edad: ");
            out.println(request.getParameter("edad"));
            out.println("<br>");
            
            out.println("color: ");
            out.println(request.getParameter("color"));
            out.println("<br>");
            
            out.println("<hr>");
            out.println("<br>");
            
            Enumeration parametros = null;
            out.println("Lista de los nombres de los parametros");
            out.println("<br>");

            parametros = request.getParameterNames();
            while (parametros.hasMoreElements()){
                out.println(parametros.nextElement());
            }
            out.println("<hr>");
            out.println("<br>");
            
            out.println("lista de los parameros sin saber el nombre");
            out.println("<br>");
            
            it = request.getParameterMap().keySet().iterator();
            
            while (it.hasNext()) {
                
                nombreParametro=(String)it.next();
                out.println("nombre del parametro: ");
                out.println(nombreParametro);
                out.println("Valores del parametro: ");
                valoresParametro = (String[])request.getParameterMap().get(nombreParametro);
                for (String valorParametro:valoresParametro){
                    out.println(valorParametro);
                    out.println(";");
                }
                out.println("<br>");
            }
            
            out.println("</body>");
            out.println("</html>");
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
