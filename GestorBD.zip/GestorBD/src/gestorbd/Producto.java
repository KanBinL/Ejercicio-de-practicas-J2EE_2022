/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestorbd;

import java.util.UUID;

/**
 *
 * @author DAW204
 */
public class Producto {
    private String idProducto = "";
    private String nombre = "";
    private String marca = "";
    private String proveedor = "";
    private double precio = 0;
    private int dto = 0;
    private int iva = 0;
    private boolean activo = false;
    
    public Producto(){
    }
    
    
    
    Producto(String miNombre, String miMarca, String miProveedor, double prec, int descuento, int eliva, boolean estado){
        idProducto = UUID.randomUUID().toString();
        nombre = miNombre;
        marca = miMarca;
        proveedor = miProveedor;
        precio = prec;
        dto = descuento;
        iva = eliva;
        activo = estado;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setProveedor(String proveedor) {
        this.proveedor = proveedor;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setDto(int dto) {
        this.dto = dto;
    }

    public void setIva(int iva) {
        this.iva = iva;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMarca() {
        return marca;
    }

    public String getProveedor() {
        return proveedor;
    }

    public double getPrecio() {
        return precio;
    }

    public int getDto() {
        return dto;
    }

    public int getIva() {
        return iva;
    }

    public boolean isActivo() {
        return activo;
    }
}




