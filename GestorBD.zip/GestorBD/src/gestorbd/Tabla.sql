/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  DAW204
 * Created: 09-feb-2023
 */
CREATE TABLE `producto` (
    `idProducto` varchar(60) NOT NULL,
    `nombre` varchar(35) NOT NULL,
    `marca` varchar(255) NOT NULL,
    `proveedor` varchar(255) NOT NULL,
    `precio` float(6,2) NOT NULL,
    `dto` int NOT NULL,
    `iva` int NOT NULL,
    `activo` boolean NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;