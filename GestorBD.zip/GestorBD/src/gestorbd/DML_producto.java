package gestorbd;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author DAW204
 */
import java.sql.*;
public class DML_producto {
    public  boolean insetProducto(Producto producto, Connection BD) {
        try {
            Statement st = BD.createStatement();
            String Activo = "";
            if (producto.isActivo()) Activo = "1"; else Activo = "0"; 
            st.executeUpdate("INSERT INTO producto " + "VALUE ('" + producto.getIdProducto() + "','" + producto.getNombre() + " ','"
                    + producto.getMarca() + "','"
                    + producto.getProveedor() + "',"
                    + producto.getPrecio()+ ","
                    + producto.getDto() + ","
                    + producto.getIva() + ","
                    + Activo + ")");
            return true;
        } catch (SQLException el){
            el.printStackTrace();
            return false;
        }
    }
}
