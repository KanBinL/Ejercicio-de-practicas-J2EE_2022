/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.Serializable;

/**
 *
 * @author ifhprof01
 */
public class Persona implements Serializable {
    String codigo;
    String nombre;
    Integer sueldo;
    String sexo;
    String profesion;

    public Persona() {
    }

    public Persona(String codigo, String nombre, Integer sueldo, String sexo, String profesion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.sueldo = sueldo;
        this.sexo = sexo;
        this.profesion = profesion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getSueldo() {
        return sueldo;
    }

    public void setSueldo(Integer sueldo) {
        this.sueldo = sueldo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getProfesion() {
        return profesion;
    }

    public void setProfesion(String profesion) {
        this.profesion = profesion;
    }

    @Override
    public String toString() {
        return "Persona{" + "codigo=" + codigo + ", nombre=" + nombre + ", sueldo=" + sueldo + ", sexo=" + sexo + ", profesion=" + profesion + '}';
    }

}
