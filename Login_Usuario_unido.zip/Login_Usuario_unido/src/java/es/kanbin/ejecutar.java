/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.kanbin;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author DAW204
 */
public class ejecutar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            Connection conn=null;
            Statement stmt=null;
            ResultSet rset=null;
        
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) { 
                Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            
            String userName="root";
            String password="";
            
            
            String url="jdbc:mysql://localhost/usuario";
            
            try {
                conn = (Connection) DriverManager.getConnection(url,userName,password);
            } catch (SQLException ex) {
                Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try {
                stmt= (Statement) conn.createStatement();
            } catch (SQLException ex) {
                Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Resultado de la Consulta</title>");            
            out.println("</head>");
            out.println("<body>");
            
            String boton = request.getParameter("boton");
            
            if(boton.equals("registrar_l")){
                RequestDispatcher rd = null;
                rd = getServletContext().getRequestDispatcher("/registrar.jsp");
                //request.setAttribute("resultado", resultado);
                rd.forward(request, response);
            }
            
            
            if(boton.equals("registrar")){
                String sqlStr="insert into dato (correo, pass) value ('" + request.getParameter("correo") + "','" + request.getParameter("pass") + "')";

                out.println(sqlStr);

                try {
                    stmt.executeUpdate(sqlStr);
                } catch (SQLException ex) {
                    Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                String resultado = "Registrar correctamente";
                
                RequestDispatcher rd = null;
                rd = getServletContext().getRequestDispatcher("/respuesta2.jsp");
                request.setAttribute("resultado", resultado);
                rd.forward(request, response);
            }
            
            
            
            
            if(boton.equals("login")){
                String sqlStr="select * from dato where correo = '" + request.getParameter("usuario") + "'";
                String resultado = "";
                try {
                    rset=stmt.executeQuery(sqlStr);
                } catch (SQLException ex) {
                    Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
                }

                int count=0;
                try {
                    while (rset.next()) {
                        if(rset.getString("correo").equals(request.getParameter("usuario")) && rset.getString("pass").equals(request.getParameter("pass"))){
                           resultado = "<h1>Bienvenido " + request.getParameter("usuario") + "</h1>";
                        } else {
                           resultado = "Acceso denegado";
                        }
                        count++;
                    }
                    
                    if (count == 0){
                        resultado = "Usuario no existe";
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                                
                
                RequestDispatcher rd = null;
                rd = getServletContext().getRequestDispatcher("/respuesta1.jsp");
                request.setAttribute("resultado", resultado);
                rd.forward(request, response);
            }
            
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ejecutar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
