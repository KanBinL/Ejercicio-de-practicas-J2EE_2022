window.onload = function () {
    crearElementos();
  };


function crearElementos() {
    $('body').append('<div id="map" style="height: 500px; width: 100%;"></div>');
    $('#map').append('<p id="contenido"></p><input type="file" id="json-file" accept=".json"><p id="mensajes"></p>');
    $('#contenido').ready(function() {
        $('#json-file').change(function() {
            var archivo = $(this)[0].files[0];
            var lector = new FileReader();

            if (archivo) {
            if (archivo.type.match('text.*')) {
                lector.readAsText(archivo);
                lector.onload = function(event) {
                $('#contenido').text(event.target.result);
                };
            } else {
                $('#mensajes').text('El archivo seleccionado no es un archivo de texto.');
            }
            } else {
            $('#mensajes').text('No se ha seleccionado ningún archivo.');
            }
        });
    });
}

